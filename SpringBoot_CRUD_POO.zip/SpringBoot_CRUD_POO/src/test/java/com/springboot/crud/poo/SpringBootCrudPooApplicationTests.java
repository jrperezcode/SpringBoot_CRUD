package com.springboot.crud.poo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCrudPooApplicationTests {

	@Test
	void contextLoads() {
	}

}
