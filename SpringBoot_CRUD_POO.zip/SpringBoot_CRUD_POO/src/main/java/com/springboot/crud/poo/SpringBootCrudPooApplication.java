package com.springboot.crud.poo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCrudPooApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCrudPooApplication.class, args);
	}

}
