package com.springboot.crud.pr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCrudPrApplicationTests {

	@Test
	void contextLoads() {
	}

}
