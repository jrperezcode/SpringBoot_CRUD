package com.springboot.crud.pf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCrudPfApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCrudPfApplication.class, args);
	}

}
